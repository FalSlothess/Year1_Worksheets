# Worksheet 1: SpaceChem
*This is the submission folder for worksheet 1. Please see the learning space for the complete instructions.*

You should submit the following:

* Spacechem savefile ( `000.user` )
* **Link** to onedrive folder with videos, or (unlisted) youtube playlist ( `videos.txt` )

If the required files are present, or cannot be opened your mark may be negatively affected.
