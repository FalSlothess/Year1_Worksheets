# COMP101 Submission Template

This assignment is made up of multiple *worksheets*. You can find these worksheets and what you are expected to do for them on the learning space.
For each worksheet you are expected to submit the requested files in the correct folders. A link to your repository should then be provided on the learning space submission area.

* For each worksheet, check what the expected submission is. It will usually be evidence of a quiz and a c-sharp file. Be careful with your naming conventions for these files.
* When using this repository, you should create your repository under the _Games Academy Student Work_ organistation with the correct year. You also should use your student number in the repository name.
