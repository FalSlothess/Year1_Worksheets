# Worksheet 2: Low-Level Representations
*This is the submission folder for worksheet 2. Please see the learning space for the complete instructions.*

This folder should contain:

* A PDF of your final quiz score and answers (`quiz.pdf`)
* A C-Sharp file which contains your [solution](https://github.falmouth.ac.uk/Games-Academy/comp101-2324-ws2) for that part (`Program.cs`)

If these files cannot be opened or is missing your mark may be negatively effected.
